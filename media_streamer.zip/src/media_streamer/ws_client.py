import json
import time

import websocket

# import inject

import rel

from collections import deque

# from media_streamer.logger import Logger
# import media_streamer.logger as Logger
# from threading import Timer


class WSClient:
    """Websocket client class"""
    _instance = None
    _initialized = False
    
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(WSClient, cls).__new__(cls)
            print(f"[SINGLETON] Creating new instance")
        else:
            print(f"[SINGLETON] Returning existing instance")
        return cls._instance

    def __init__(self, host: str, auth_key: str, robot_id: str, serial: str, logger) -> None:
        if self._initialized:
            self.logger.info(f"[SINGLETON] Using existing WSClient instance")
            return

        # self.logger = inject.attr(Logger)
        self.logger = logger

        self.logger.info(f"[SINGLETON] Creating new WSClient instance - Connecting to websocket {host}")

        self.robot_id = robot_id

        self.header = {
            "authorization": "secret-token",
            "x-api-key": auth_key,
            "x-robot-id": robot_id,
            "x-serial": str(serial)
        }

        self.wsapp = websocket.WebSocketApp(
            host, on_open=self._on_open,
            on_message=self._on_message,
            on_close=self._on_close,
            on_error=self._on_error,
            header=self.header
        )

        self._on_callbacks = {}

        self.message_queue = deque()

        self.is_connecting = False

        self.is_interupted = False

        self.is_connected = False
        
        self._initialized = True

    def _on_open(self, _) -> None:
        """Called when a websocket is connected"""
        self.logger.info("Websocket connected")

        self.is_connected = True

        self._on_callbacks["connected"]()

        # self.send("join", {
        #     "robot_id": self.robot_id
        # })

        # time.sleep(2)
        # while len(self.message_queue) > 0:
        #     message = self.message_queue.popleft()
        #     self.wsapp.send(message)


    def join(self) -> None:
        """
        Join to websocket
        """
        
        self.send("join", {
            "robot_id": self.robot_id
        })


    def _on_close(self, _, close_status_code, close_msg) -> None:
        """Called when a websocket is disconnected"""
        self.logger.info(
            f"Websocket closed with status code {close_status_code} and message {close_msg}")

        # if self.is_connecting:
        #     return
        # self.logger.info("Reconnecting to websocket...")
        # time.sleep(5)
        # self.connect()

    def _on_message(self, _, message) -> None:
        """Called when a message is received from the websocket"""
        self.logger.info(f"Websocket message received: {message}")
        message = json.loads(message)

        action = message.get("action", None)
        payload = message.get("payload", {})

        if action is None:
            # if error message
            # self.logger.error("Action is not exists")
            # error_msg = message.get("message", None)
            # if error_msg is not None:
            #     self.logger.error(error_msg)
            #     self._on_callbacks["error"](error_msg)
            self.disconnect()
        elif action not in self._on_callbacks:
            # raise Exception(f"Callback for action {action} does not exist")
            self.logger.error(f"Callback for action {action} does not exist")
        else:
            self._on_callbacks[action](payload)

    def _on_error(self, _, error) -> None:
        """Called when an error occurs on the websocket"""
        self.logger.error(f"Websocket error: {error}")


    def connect(self) -> None:
        """Connects to the websocket"""

        if self.is_connecting or self.is_interupted:
            self.logger.info(f"[SINGLETON] Already connecting or interrupted, skipping...")
            return

        self.logger.info(f"[SINGLETON] Starting connection...")
        self.is_connecting = True

        # self.wsapp.run_forever(dispatcher=rel, reconnect=5)
        try:
            # self.wsapp.run_forever(dispatcher=rel, ping_interval=30, ping_timeout=20)
            # TODO : ping_interval, ping_timeout 
            # ws connection status check
            # print(f"wsapp connect : ${self.wsapp.sock}")
            self.wsapp.run_forever()
            # print(f"wsapp connected : ${self.wsapp.sock.connected}")

            if self.is_connected:
                self._on_callbacks["disconnected"]()
                self.is_connected = False

            if self.is_interupted:
                return

            # rel.signal(2, rel.abort)
            # rel.dispatch()
        except Exception as error:
            self.logger.error(f"Websocket error: {error}")

            # self.logger.info("Reconnecting to websocket...")
            # if self.is_connecting:
            #     return

        self.logger.info("Reconnecting to websocket...")

        time.sleep(3)

        self.is_connecting = False
        self.connect()



    def disconnect(self) -> None:
        """Disconnects from the websocket"""
        try:
            self.is_interupted = True
            self.wsapp.close()
        except Exception as error:
            self.logger.error(f"Websocket error: {error}")

    # def send(self, action: str, payload: dict, msg_type: str) -> None:
    def send(self, action: str, payload: dict) -> None:
        """Sends a message to the websocket"""
        # self.wsapp.recv()
        # self.wsapp.sock.recv()
        # logger.info(f"send ws connected : ${self.wsapp.sock.connected} action: {action}, payload: {payload}")

        if self.wsapp.sock and self.wsapp.sock.connected:
            self.wsapp.send(json.dumps(
                {"action": action, "robot_id": self.robot_id, "payload": payload}))
        else:
            self.message_queue.append(json.dumps(
                {"action": action, "robot_id": self.robot_id, "payload": payload}))

    def on(self, action: str, callback) -> None:
        """Registers a callback for a action"""

        if action in self._on_callbacks:
            raise Exception(f"Callback for action {action} is not exists")

        self._on_callbacks[action] = callback

    def off(self, action: str) -> None:
        """Unregisters a callback for a action"""

        if action not in self._on_callbacks:
            raise Exception(f"Callback for action {action} is not exists")

        del self._on_callbacks[action]


    def on_error(self, callback) -> None:
        """Called when an error occurs on the websocket"""
        # TODO : error callback
        # this is server error callback
        self._on_callbacks["error"] = callback

# Path: src\media_streamer\connector.py
